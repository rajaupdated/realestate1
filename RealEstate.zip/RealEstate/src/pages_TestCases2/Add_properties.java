package pages_TestCases2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Add_properties {
WebDriver dr;
	
	By properties=By.xpath("//*[@id=\"menu-posts-property\"]/a/div[3]");
	
	By allproperties=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[2]/a");
	
	By add=By.xpath("//*[@id=\"wpbody-content\"]/div[3]/a");
	
	By enter_title=By.xpath("//*[@id=\"title\"]");
	
	By price=By.xpath("//*[@id=\"_price\"]");
	
	
	
	By main_tab=By.xpath("//*[@id=\"ui-id-2\"]");
	
	By status=By.xpath("//*[@id=\"_status\"]");
	
	By location_box=By.xpath("//*[@id=\"_location\"]");
	
	By price_per_sqr=By.xpath("//*[@id=\"_price_per\"]");
	
	By possession=By.xpath("//*[@id=\"_possession\"]");
	
	
	
	By location=By.xpath("//*[@id=\"ui-id-3\"]");

	By address=By.xpath("//*[@id=\"_friendly_address\"]");
	
	By google_map=By.xpath("//*[@id=\"_address\"]");
	
	By latitude=By.xpath("//*[@id=\"_geolocation_lat\"]");
	
	By longitude=By.xpath("//*[@id=\"_geolocation_lat\"]");
	
	
	
	By detailes=By.xpath("//*[@id=\"ui-id-4\"]");
	
	By storage_room=By.xpath("//*[@id=\"_storage_room\"]");
	
	By central_bng_checkbox=By.xpath("//*[@id=\"acf-group_5aa6786492979\"]/div/div/div[2]/div/div[2]/ul/li[1]/ul/li[1]/label/input");
	
	By publish_button=By.xpath("//*[@id='publish']");
	
	By assert_msg=By.xpath("//*[@id=\"message\"]/p/text()");
	
	public Add_properties(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void properties() 
	{
		dr.findElement(properties).click();
		
	}
	
	public void all_properties() 
	{
		dr.findElement(allproperties).click();
		
	}
	
	public void add() 
	{
		dr.findElement(add).click();
		
	}
	
	public void enter_title(String s) 
	{
		dr.findElement(enter_title).sendKeys(s);
		
	}
	
	public void price(String p) 
	{
		dr.findElement(price).sendKeys(p);
		
	}
	
	
	public void main_tab() 
	{
		dr.findElement(main_tab).click();
		
	}
	

	public void status(String s)
	{
		dr.findElement(status).sendKeys(s);
	}
	
	public void location(String s)
	{
		dr.findElement(location).sendKeys(s);
	}
	public void price_per_sqr(String s)
	{
		dr.findElement(price_per_sqr).sendKeys(s);
	}
	

	public void possession(String s)
	{
		dr.findElement(possession).sendKeys(s);
	}
	
	

	public void location()
	{
		dr.findElement(location).click();
	}
	
	
	public void address(String s)
	{
		dr.findElement(address).sendKeys(s);
	}
	
	
	public void google_map(String s)
	{
		dr.findElement(google_map).sendKeys(s);
	}
	
	
	public void latitude(String s)
	{
		dr.findElement(latitude).sendKeys(s);
	}
	
	
	
	public void longitude(String s)
	{
		dr.findElement(longitude).sendKeys(s);
	}
	
	
	public void detailes()
	{
		dr.findElement(detailes).click();
	}
	
	
	public void storage_room(String s)
	{
		dr.findElement(storage_room).sendKeys(s);
	}
	
	
	
	public void cental_bng_checkbox()
	{
		WebElement we=dr.findElement(central_bng_checkbox);
		we.click();
		
	}
	
	
	public void publish_button()
	{
		dr.findElement(publish_button).submit();
	}
	
	public String sucess_msg()
	{
		return dr.findElement(assert_msg).getText();
		}
	

	public void add_properties_main(String a,String b,String c,String d,String e,String f,String g,String h,String i,String j,String k)
	{
		this.properties();
	
		this.all_properties();
		
		this.add();
		
		this.enter_title(a);
		
		this.price(b);
		this.price_per_sqr(c);
		
		this.main_tab();
		this.status(d);
		this.location(e);
		this.possession(f);
		
		this.location();
		this.address(g);
		this.google_map(h);
		this.latitude(i);
		this.longitude(j);
		
		this.detailes();
		this.storage_room(k);
		
		this.cental_bng_checkbox();
		
		this.publish_button();
	}
	
}
