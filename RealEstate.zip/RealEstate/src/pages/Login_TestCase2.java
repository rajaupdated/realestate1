package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_TestCase2 {
	
WebDriver dr;
	
	By login_reg=By.xpath("//*[@id='responsive']/li[7]/a");
	
	
	By email=By.xpath("//*[@id=\"user_login\"]");
	
	By paswd=By.xpath("//*[@id=\"user_pass\"]");
	
	By sign_in=By.xpath("//*[@id=\"tab1\"]/form/p[3]/input");
	
	By login_text=By.xpath("//*[@id=\"titlebar\"]/div/div/div/span");
	
	
	public Login_TestCase2(WebDriver dr)
	{
		this.dr=dr;
	}
	
	
	public void click_login_reg()
	{
		dr.findElement(login_reg).click();
	}
	
	public void enter_email( String e)
	{
		dr.findElement(email).sendKeys(e);
	}
	
	public void enter_paswd( String p)
	{
		dr.findElement(paswd).sendKeys(p);
	}
	
	public void click_signIn()
	{
		dr.findElement(sign_in).click();
	}
	
	public String sucess_msg()
	{
		return dr.findElement(login_text).getText();
		}
	
	public void do_login(String e,String p )
	{
		this.click_login_reg();
		this.enter_email(e);
		this.enter_paswd(p);
		this.click_signIn();
	}
	

}
