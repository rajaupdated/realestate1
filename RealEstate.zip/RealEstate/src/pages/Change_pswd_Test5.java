package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Change_pswd_Test5 {
	
WebDriver dr;
	
	By profile=By.xpath("//*[@id=\"post-133\"]/div[1]/div/div/ul[1]/li[2]/a");
	
	By click_pswd=By.xpath("//*[@id=\"post-133\"]/div[1]/div/div/ul[2]/li[1]/a");
	
	By old_pswd=By.xpath("//*[@id=\"post-129\"]/div[2]/div/div[1]/form/input[1]");
	
	By new_pswd=By.xpath("//*[@id=\"post-129\"]/div[2]/div/div[1]/form/input[2]");
	
	By new_pswd_re=By.xpath("//*[@id=\"post-129\"]/div[2]/div/div[1]/form/input[3]");
	
	By sucess_msg=By.xpath("//*[@id=\"post-129\"]/div[2]/div/div[1]/div/p");
	
	By submit=By.xpath("//*[@id=\"wp-submit\"]");
	
	//By sucess_msg=By.xpath();
	public Change_pswd_Test5(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void click_profile()
	{
		dr.findElement(profile).click();
	}
	
	public void click_pswd()
	{
		dr.findElement(click_pswd).click();
	}
	
	public void click_old_pswd(String s)
	{
		dr.findElement(old_pswd).sendKeys(s);
	}
	
	public void click_new_pswd(String p)
	{
		dr.findElement(new_pswd).sendKeys(p);
	}
	
	public void click_pswd_re(String re)
	{
		dr.findElement(new_pswd_re).sendKeys(re);
	}

	public void submit()
	{
		dr.findElement(submit).click();
	}
	
	public String sucess_msg()
	{
		return dr.findElement(sucess_msg).getText();
	}
	
	public void change_pswd(String old_pswd,String new_pswd,String new_pswd_re)
	{
		this.click_profile();
		this.click_pswd();
		this.click_old_pswd(old_pswd);
		this.click_new_pswd(new_pswd);
		this.click_pswd_re(new_pswd_re);
		this.submit();
		
	}
}
