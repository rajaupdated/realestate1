package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Registration_TestCase1 {
	
	WebDriver dr;
	
	By login_reg=By.xpath("//*[@id='responsive']/li[7]/a");
	
	
	
	By reg=By.xpath("//*[@id='post-133']/div/div/div/ul/li[2]/a");
	
	By email=By.xpath("//*[@id=\"email\"]");

	By fname=By.xpath("//*[@id=\"first-name\"]");
	
	By lname=By.xpath("//*[@id=\"last-name\"]");
	
	By submit=By.xpath("//*[@id=\"signupform\"]/p[5]/input");
	
	By sucess_msg=By.xpath("//*[@id='post-133']/div/div/div/div[1]/p");
	
	public Registration_TestCase1(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void click_login_reg()
	{
		dr.findElement(login_reg).click();
	}
	
	public void reg()
	{
		dr.findElement(reg).click();
	}
	
	public void email(String e)
	{
		dr.findElement(email).sendKeys(e);
		
	}
	
	public void fname(String fn)
	{
		dr.findElement(fname).sendKeys(fn);
		
	}
	
	public void lname(String ln)
	{
		dr.findElement(lname).sendKeys(ln);
		
	}
	
	public void submit()
	{
		dr.findElement(submit).click();
		
	}
	
	public String sucess_msg()
	{
	return dr.findElement(sucess_msg).getText();	
	}
	
	public void do_reg(String e,String fn,String ln)
	{
		this.click_login_reg();
		this.reg();
		this.email(e);
		this.fname(fn);
		this.lname(ln);
		this.submit();
		
	}
	


	
	
	

}
