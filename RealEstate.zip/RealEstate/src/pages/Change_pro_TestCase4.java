package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Change_pro_TestCase4 {
	
WebDriver dr;
	
	By profile=By.xpath("//*[@id=\"post-133\"]/div[1]/div/div/ul[1]/li[2]/a");
	
	
	By agent_name=By.xpath("//*[@id='agent_title']");
	
	By ph_no=By.xpath("//*[@id=\"phone\"]");
	
	By submit=By.xpath("//*[@id=\"edit_user\"]/button");
	
	By sucess_msg=By.xpath("//*[@id=\"post-133\"]/div[2]/div/div[1]/div/p");
	
	public Change_pro_TestCase4(WebDriver dr)
	{
		this.dr=dr;
	}
	public void click_list()
	{
		dr.findElement(profile).click();
	}
	
	public void agent_name(String an)
	{
		dr.findElement(agent_name).sendKeys(an);
		 }
	public void ph_no(String pn)
	{
		dr.findElement(ph_no).sendKeys(pn);
	}
	public void submit()
	{
		dr.findElement(submit).click();
	}
	public String sucess_msg()
	{
	return dr.findElement(sucess_msg).getText();	
	}
	
	public void change_pro(String s,String n)
	{
		this.click_list();
		this.agent_name(s);
		this.ph_no(n);
		this.submit();
	}
}

