package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Recovery_pswd_TestCase3 {

	
	WebDriver dr;
	
	By login_reg=By.xpath("//*[@id='responsive']/li[7]/a");
	//*[@id="responsive"]/li[8]/a
	By lost_ur_pswd=By.xpath("/html[1]/body[1]/div[1]/div[4]/div[1]/article[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/p[4]/a[1]");
	
	By enter_email=By.xpath("//*[@id=\"user_login\"]");
	
	By reset_pswd=By.xpath("//*[@id=\"lostpasswordform\"]/p[2]/input");
	
	By msg=By.xpath("//*[@id=\"error-page\"]/p");
	
	public Recovery_pswd_TestCase3(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void click_login_reg()
	{
		dr.findElement(login_reg).click();
	}
	
	public void click_lost_pswd()
	{
		dr.findElement(lost_ur_pswd).click();	
		WebDriverWait wait1=new WebDriverWait(dr,50);
		wait1.until(ExpectedConditions.elementToBeClickable(lost_ur_pswd));
		
	}
	
	public void email(String e)
	{
		
		dr.findElement(enter_email).sendKeys(e);
		
	}
	
	public void reset_pswd()
	{
		dr.findElement(reset_pswd).click();
	}
	
	public String sucess_msg()
	{
		return dr.findElement(msg).getText();
	}
	
	public void do_pswd_reset(String e)
	{
		this.click_login_reg();
		this.click_lost_pswd();
		this.email(e);
		this.reset_pswd();
		
	}
}
