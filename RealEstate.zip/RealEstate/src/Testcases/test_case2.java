package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Login_TestCase2;
import pages_TestCases2.Add_properties;

public class test_case2 {
	
	WebDriver dr;
	Add_properties ap;
	Login_TestCase2 ltc;
	
	
	@BeforeClass
	  public void launchChrome() {
		  
		  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		  dr=new ChromeDriver();
		 dr.get("http://realestate.upskills.in/");
		  
	  }
	
	
  @Test
  public void add_properties() {
	  
	  ltc=new   Login_TestCase2(dr);
	 
	  ap=new Add_properties(dr);
	  
	  ltc.do_login("admin","admin@123");
	  
	  ap.add_properties_main("new launch","new launch","50000.00","200.00","New","Electronic city","immediate","yeshwanthapur","yeshwanthapur","120","56");
	  
	  Assert.assertTrue(ap.sucess_msg().contains("Post published. "));
  }
}
