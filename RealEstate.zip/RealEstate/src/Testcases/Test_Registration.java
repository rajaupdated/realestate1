package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Change_pro_TestCase4;
import pages.Change_pswd_Test5;
import pages.Login_TestCase2;
import pages.Recovery_pswd_TestCase3;
import pages.Registration_TestCase1;



public class Test_Registration {
	
	WebDriver dr;
	Registration_TestCase1 rtc;
	Login_TestCase2 ltc;
	Recovery_pswd_TestCase3 rpt;
	Change_pro_TestCase4 cpt;
	Change_pswd_Test5 cpswd;
	
	//*[@id="user_login"]
	
  @BeforeClass
  public void launchChrome() {
	  
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	  dr=new ChromeDriver();
	 dr.get("http://realestate.upskills.in/");
	  
  }
  
  //@Test
  public void TestCase1()
  {
	rtc=new   Registration_TestCase1(dr);
	
	
	rtc.do_reg("abhishekraja@gmail.com","abhishek raja","abhishek raja");
	
	String sucess_msg=rtc.sucess_msg();
	dr.close();
	Assert.assertTrue(sucess_msg.contains("You have successfully registered to Real Estate. We have emailed your password to the email address you entered."));
	System.out.println("Test_Case one Scuessful");
  }
  
// @Test
  public void TestCase2()
  {
	ltc=new   Login_TestCase2(dr);
	
	ltc.do_login("abhishekraja@gmail.com","abhishek raja");
	
	String sucess_msg=ltc.sucess_msg();
	dr.close();
	Assert.assertTrue(sucess_msg.contains("Howdy, abhishek raja K!"));
	System.out.println("Test_Case TWO Scuessful");
	
	}
  
  //@Test
  public void TestCase3()
  {
	rpt =new Recovery_pswd_TestCase3(dr);
	
	rpt.do_pswd_reset("abhishekraja@gmail.com");
	
	String sucess_msg=rpt.sucess_msg();
	
	Assert.assertTrue(sucess_msg.contains("Password has been changed."));
	  
  }



//@Test
public void TestCase4()
{
	ltc=new   Login_TestCase2(dr);
	cpt=new Change_pro_TestCase4(dr);
	
	ltc.do_login("abhishekraja@gmail.com","abhishek raja");

	cpt.change_pro("abhishek","9573574191");
	String sucess_msg= cpt.sucess_msg();
	dr.close();
	Assert.assertTrue(sucess_msg.contains("Your profile has been updated."));
	
}

@Test
public void TestCase5()
{
	ltc=new   Login_TestCase2(dr);
	cpswd=new Change_pswd_Test5(dr);

	ltc.do_login("abhishekraja@gmail.com","abhishek raja");

	cpswd.change_pswd("abhishek raja","9573574191","9573574191"); //9573574191 abhishek raja
	
	String sucess_msg=cpswd.sucess_msg();
	dr.close();
	Assert.assertTrue(sucess_msg.contains("Your password has been updated."));
	
}
























}


