package Testcases;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.Change_pro_TestCase4;
import pages.Change_pswd_Test5;
import pages.Login_TestCase2;
import pages.Recovery_pswd_TestCase3;
import pages.Registration_TestCase1;

public class chrome_TestNG {
	public class Hub_Node {
		
		WebDriver dr;
		String autURL, nodeURL;
		Registration_TestCase1 rtc;
		Login_TestCase2 ltc;
		Recovery_pswd_TestCase3 rpt;
		Change_pro_TestCase4 cpt;
		Change_pswd_Test5 cpswd;
		
		
	  @BeforeMethod
	  public void launchChrome1() throws MalformedURLException {
		  
		 
		  autURL = "http://realestate.upskills.in/";
		  nodeURL = "http://172.24.98.13:9018/wd/hub";
		  DesiredCapabilities cap = DesiredCapabilities.chrome();
		  cap.setBrowserName("chrome");
		  cap.setPlatform(Platform.WINDOWS);
		  dr = new RemoteWebDriver(new URL(nodeURL), cap);
		  dr.get(autURL);
		  TestCase2(); 
		  
		  
	  }
	  
	  @Test(priority=0)
	  public void TestCase1()
	  {
		rtc=new   Registration_TestCase1(dr);
		
		
		rtc.do_reg("abhishekraja6@gmail.com","rer","erer");
		
		String sucess_msg=rtc.sucess_msg();
		
		Assert.assertTrue(sucess_msg.contains("You have successfully registered to Real Estate. We have emailed your password to the email address you entered."));
		System.out.println("Test_Case one Scuessful");
		dr.close();
	  }
	  
	 
	  @Test(priority=1)
	  public void TestCase2()
	  {
		ltc=new   Login_TestCase2(dr);
		
		ltc.do_login("abhishekraja@gmail.com","abhishek raja");
		
		String sucess_msg=ltc.sucess_msg();
		Assert.assertTrue(sucess_msg.contains("Howdy, abhishek raja k!"));
		System.out.println("Test_Case TWO Scuessful");
		dr.close();
		}
	  
//	  @Test
//	  public void TestCase3()
//	  {
//		rpt =new Recovery_pswd_TestCase3(dr);
//		
//		rpt.do_pswd_reset("abhishekraja@gmail.com");
//		
//		String sucess_msg=rpt.sucess_msg();
//		
//		Assert.assertTrue(sucess_msg.contains("Password has been changed."));
//		dr.close();
//	  }
//


	  @Test(priority=3)
	public void TestCase4()
	{
		ltc=new   Login_TestCase2(dr);
		cpt=new Change_pro_TestCase4(dr);
		
		ltc.do_login("abhishekraja@gmail.com","abhishek raja");

		cpt.change_pro("abhishek","9573574191");
		String sucess_msg= cpt.sucess_msg();
		Assert.assertTrue(sucess_msg.contains("Your profile has been updated."));
		dr.close();
	}

	  @Test(priority=4)
	public void TestCase5()
	{
		ltc=new   Login_TestCase2(dr);
		cpswd=new Change_pswd_Test5(dr);

		ltc.do_login("abhishekraja@gmail.com","abhishek raja");

		cpswd.change_pswd("9573574191","abhishek raja","abhishek raja");
		
		String sucess_msg=cpswd.sucess_msg();
		
		Assert.assertTrue(sucess_msg.contains("Your password has been updated."));
		
	}

  }
}
